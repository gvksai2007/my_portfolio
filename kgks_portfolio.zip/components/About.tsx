import React from 'react';
import { MY_NAME } from '../constants';

export default function About() {
  return (
    <section id="about" className="section-animate min-h-[60vh] flex items-center">
      <div className="w-full">
        <h2 className="font-display text-5xl md:text-7xl lg:text-8xl text-marvel-red-500 tracking-wider mb-4">HELLO, I'M</h2>
        <h1 className="font-bold text-4xl md:text-6xl lg:text-7xl text-gray-800 dark:text-gray-100 mb-6 leading-tight">
          {MY_NAME}.
        </h1>
        <p className="max-w-3xl text-lg md:text-xl text-gray-600 dark:text-gray-400">
          A passionate and aspiring developer with a keen interest in Artificial Intelligence and Machine Learning. I am on a journey to build innovative and impactful solutions that push the boundaries of technology.
        </p>
      </div>
    </section>
  );
};
