import React, { useState, useEffect } from 'react';
import { Theme } from '../types';
import ThemeToggle from './ThemeToggle';
import SocialIcons from './SocialIcons';

interface HeaderProps {
  theme: Theme;
  toggleTheme: () => void;
}

export default function Header({ theme, toggleTheme }: HeaderProps) {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleNavClick = (e: React.MouseEvent<HTMLAnchorElement>) => {
    e.preventDefault();
    const href = e.currentTarget.getAttribute('href');
    if (href === null) return;

    // Close mobile menu on any nav click
    if (isMenuOpen) {
      setIsMenuOpen(false);
    }

    // Handle scroll to top for logo/home link
    if (href === '#') {
      window.scrollTo({
        top: 0,
        behavior: 'smooth',
      });
      return;
    }

    const targetId = href.substring(1);
    const targetElement = document.getElementById(targetId);

    if (targetElement) {
      const headerHeight = 80; // Corresponds to h-20 in Tailwind
      const elementPosition = targetElement.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.scrollY - headerHeight;

      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
    }
  };
  
  const navLinks = ["about", "education", "experience", "projects", "contact"];
  
  const navLinkClasses = "block md:inline-block py-2 md:py-0 px-4 md:px-0 text-gray-400 hover:text-marvel-red-500 transition-colors duration-300 border-b-2 border-transparent hover:border-marvel-red-500";

  return (
    <header className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${isScrolled ? 'bg-marvel-dark/80 dark:bg-marvel-dark/90 backdrop-blur-sm shadow-lg' : 'bg-transparent'}`}>
      <div className="container mx-auto px-6 sm:px-8 md:px-12">
        <div className="flex items-center justify-between h-20">
          <a href="#" onClick={handleNavClick} className="text-2xl font-display tracking-wider text-white hover:text-marvel-red-500 transition-colors duration-300">
            KGKS
          </a>
          
          <nav className="hidden md:flex items-center space-x-8">
            {navLinks.map(link => (
              <a key={link} href={`#${link}`} onClick={handleNavClick} className={navLinkClasses}>
                {link.charAt(0).toUpperCase() + link.slice(1)}
              </a>
            ))}
          </nav>

          <div className="hidden md:flex items-center space-x-4">
            <SocialIcons />
            <ThemeToggle theme={theme} toggleTheme={toggleTheme} />
          </div>

          <div className="md:hidden flex items-center">
             <ThemeToggle theme={theme} toggleTheme={toggleTheme} />
             <button onClick={() => setIsMenuOpen(!isMenuOpen)} className="ml-4 text-gray-200 focus:outline-none">
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d={isMenuOpen ? "M6 18L18 6M6 6l12 12" : "M4 6h16M4 12h16m-7 6h7"}></path>
                </svg>
            </button>
          </div>
        </div>

        {isMenuOpen && (
            <div className="md:hidden pb-4">
                <nav className="flex flex-col items-center space-y-2">
                     {navLinks.map(link => (
                        <a key={link} href={`#${link}`} onClick={handleNavClick} className={navLinkClasses}>
                            {link.charAt(0).toUpperCase() + link.slice(1)}
                        </a>
                    ))}
                    <div className="pt-4">
                        <SocialIcons />
                    </div>
                </nav>
            </div>
        )}
      </div>
    </header>
  );
};
