import React from 'react';
import { EDUCATION_DATA } from '../constants';

export default function Education() {
  return (
    <section id="education" className="section-animate">
      <h2 className="text-center font-display text-4xl md:text-5xl text-marvel-red-500 tracking-widest mb-12">
        EDUCATION
      </h2>
      <div className="relative max-w-2xl mx-auto">
        <div className="absolute left-1/2 w-1 h-full bg-marvel-gray-700 dark:bg-marvel-gray-800 transform -translate-x-1/2"></div>
        {EDUCATION_DATA.map((item, index) => (
          <div key={index} className="relative mb-8 flex items-center w-full">
            <div className={`w-1/2 ${index % 2 === 0 ? 'pr-8 text-right' : 'pl-8 text-left ml-auto'}`}>
              <div className="p-4 bg-white dark:bg-marvel-gray-800 rounded-lg shadow-md border border-gray-200 dark:border-marvel-gray-700">
                <p className="font-bold text-marvel-red-500 text-lg">{item.degree}</p>
                <p className="text-md font-semibold text-gray-700 dark:text-gray-300">{item.institution}</p>
                <p className="text-sm text-gray-500 dark:text-gray-400 mb-2">{item.period}</p>
                <p className="text-sm text-gray-600 dark:text-gray-400">{item.details}</p>
              </div>
            </div>
            <div className="absolute left-1/2 transform -translate-x-1/2 w-4 h-4 bg-marvel-red-500 rounded-full border-4 border-marvel-light dark:border-marvel-dark"></div>
          </div>
        ))}
      </div>
    </section>
  );
};
