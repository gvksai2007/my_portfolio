import React, { useState, useEffect, useCallback } from 'react';
import { Theme } from './types';
import Header from './components/Header';
import About from './components/About';
import Education from './components/Education';
import Experience from './components/Experience';
import Projects from './components/Projects';
import Contact from './components/Contact';
import QuoteBanner from './components/QuoteBanner';

const BackgroundFlashes: React.FC = () => {
  const flashes = Array.from({ length: 20 }).map((_, i) => ({
    id: i,
    top: `${Math.random() * 100}%`,
    left: `${Math.random() * 100}%`,
    animationDuration: `${Math.random() * 2 + 2}s`,
    animationDelay: `${Math.random() * 4}s`,
    width: `${Math.random() * 2 + 2}px`,
  }));

  return (
    <div className="fixed top-0 left-0 w-full h-full -z-10 pointer-events-none" aria-hidden="true">
      {flashes.map(flash => (
        <div
          key={flash.id}
          className="absolute rounded-full bg-yellow-400/50 dark:bg-yellow-300/70 animate-flash"
          style={{
            top: flash.top,
            left: flash.left,
            width: flash.width,
            height: flash.width,
            animationDuration: flash.animationDuration,
            animationDelay: flash.animationDelay,
            boxShadow: '0 0 8px 2px rgba(250, 204, 21, 0.4)',
          }}
        />
      ))}
    </div>
  );
};

const BackgroundPlanets: React.FC = () => {
  const planets = [
    { id: 1, size: '15vw', top: '10%', left: '15%', color: 'rgba(237, 29, 36, 0.2)', duration: '12s', delay: '0s' },
    { id: 2, size: '8vw', top: '65%', left: '80%', color: 'rgba(78, 89, 237, 0.2)', duration: '8s', delay: '3s' },
    { id: 3, size: '5vw', top: '70%', left: '5%', color: 'rgba(178, 78, 237, 0.2)', duration: '10s', delay: '5s' },
    { id: 4, size: '12vw', top: '40%', left: '45%', color: 'rgba(237, 142, 78, 0.2)', duration: '15s', delay: '1s' },
  ];

  return (
    <div className="fixed top-0 left-0 w-full h-full -z-20 pointer-events-none" aria-hidden="true">
      {planets.map(planet => (
        <div
          key={planet.id}
          className="absolute rounded-full animate-flash"
          style={{
            top: planet.top,
            left: planet.left,
            width: planet.size,
            height: planet.size,
            backgroundColor: planet.color,
            animationDuration: planet.duration,
            animationDelay: planet.delay,
            boxShadow: 'inset 0 0 40px rgba(0,0,0,0.3)',
          }}
        />
      ))}
    </div>
  );
};

export default function App() {
  const [theme, setTheme] = useState<Theme>(Theme.DARK);

  useEffect(() => {
    document.body.classList.add('loaded');
  }, []);

  useEffect(() => {
    if (theme === Theme.DARK) {
      document.documentElement.classList.add('dark');
      document.body.classList.add('bg-marvel-dark');
      document.body.classList.remove('bg-marvel-light');
    } else {
      document.documentElement.classList.remove('dark');
      document.body.classList.add('bg-marvel-light');
      document.body.classList.remove('bg-marvel-dark');
    }
  }, [theme]);

  const toggleTheme = useCallback(() => {
    setTheme((prevTheme) => (prevTheme === Theme.LIGHT ? Theme.DARK : Theme.LIGHT));
  }, []);

  useEffect(() => {
    const sectionElements = document.querySelectorAll('.section-animate');
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('section-visible');
            }
        });
    }, {
        threshold: 0.1
    });

    sectionElements.forEach(sectionEl => {
        observer.observe(sectionEl);
    });

    return () => {
        sectionElements.forEach(sectionEl => {
            observer.unobserve(sectionEl);
        });
    };
  }, []);

  return (
    <div className="min-h-screen text-gray-800 dark:text-gray-200 transition-colors duration-500 isolate">
      <BackgroundFlashes />
      <BackgroundPlanets />
      <Header theme={theme} toggleTheme={toggleTheme} />
      <main className="container mx-auto px-6 sm:px-8 md:px-12 py-24 sm:py-32">
        <div className="space-y-24 md:space-y-32">
          <About />
          <Education />
          <Experience />
          <QuoteBanner />
          <Projects />
          <Contact />
        </div>
      </main>
      <footer className="text-center py-8 border-t border-marvel-gray-700 dark:border-marvel-gray-800">
        <p className="text-sm text-gray-500 dark:text-gray-400">&copy; {new Date().getFullYear()} Kunchala Govardhana Krishna Sai. All Rights Reserved.</p>
      </footer>
    </div>
  );
}