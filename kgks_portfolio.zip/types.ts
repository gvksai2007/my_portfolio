
export enum Theme {
  LIGHT = 'light',
  DARK = 'dark',
}
