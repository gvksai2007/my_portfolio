import React from 'react';
import { PROJECTS_DATA } from '../constants';

interface ProjectCardProps {
  title: string;
  description: string;
  imageUrl: string;
}

function ProjectCard({ title, description, imageUrl }: ProjectCardProps) {
  return (
    <div className="group relative overflow-hidden rounded-lg bg-marvel-gray-800 border-2 border-transparent transition-all duration-500 hover:border-marvel-red-500 hover:shadow-marvel-glow">
      <img src={imageUrl} alt={title} className="w-full h-56 object-cover transition-transform duration-500 group-hover:scale-105" />
      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent"></div>
      <div className="absolute bottom-0 left-0 p-6">
        <h3 className="text-2xl font-bold text-white mb-2">{title}</h3>
        <p className="text-gray-300 opacity-0 group-hover:opacity-100 transition-opacity duration-500 max-h-0 group-hover:max-h-40 overflow-hidden">
          {description}
        </p>
      </div>
      <div className="absolute top-4 right-4 bg-marvel-red-600 text-white text-xs font-bold px-3 py-1 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-300 transform -translate-y-2 group-hover:translate-y-0">
          COMING SOON
      </div>
    </div>
  );
}

export default function Projects() {
  return (
    <section id="projects" className="section-animate">
      <h2 className="text-center font-display text-4xl md:text-5xl text-marvel-red-500 tracking-widest mb-12">
        PROJECTS
      </h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {PROJECTS_DATA.map((project, index) => (
          <ProjectCard key={index} {...project} />
        ))}
      </div>
    </section>
  );
};
