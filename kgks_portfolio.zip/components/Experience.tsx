import React from 'react';

export default function Experience() {
  return (
    <section id="experience" className="section-animate">
      <h2 className="text-center font-display text-4xl md:text-5xl text-marvel-red-500 tracking-widest mb-12">
        EXPERIENCE
      </h2>
      <div className="text-center bg-gray-100 dark:bg-marvel-gray-800 border-l-4 border-marvel-red-500 p-8 rounded-r-lg max-w-2xl mx-auto">
        <h3 className="text-2xl font-bold text-gray-700 dark:text-gray-200 mb-2">My Journey is Just Beginning</h3>
        <p className="text-gray-600 dark:text-gray-400">
          This section is currently under construction. I am actively seeking new opportunities and experiences to apply my skills. Check back soon for updates on my professional journey!
        </p>
      </div>
    </section>
  );
};
