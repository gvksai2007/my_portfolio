import React, { useState } from 'react';
import { MY_EMAIL, SpiderWebIcon } from '../constants';

export default function Contact() {
  const [webState, setWebState] = useState<'visible' | 'tearing' | 'torn'>('visible');

  const handleWebClick = () => {
    if (webState === 'visible') {
      setWebState('tearing');
      setTimeout(() => {
        setWebState('torn');
      }, 500); // Match animation duration
    }
  };

  const isWebActive = webState !== 'torn';

  return (
    <section id="contact" className="section-animate text-center">
      <h2 className="text-center font-display text-4xl md:text-5xl text-marvel-red-500 tracking-widest mb-8">
        GET IN TOUCH
      </h2>
      <p className="text-lg text-gray-600 dark:text-gray-400 max-w-2xl mx-auto mb-8">
        I'm always open to discussing new projects, creative ideas, or opportunities to be part of an amazing team. Feel free to reach out to me.
      </p>

      <div className="relative inline-block" onClick={handleWebClick}>
        {isWebActive && (
          <div
            className={`absolute inset-0 z-10 text-slate-800/60 dark:text-slate-200/60 transition-opacity duration-300 ${
              webState === 'tearing' ? 'animate-web-tear' : ''
            } ${webState === 'visible' ? 'cursor-pointer' : 'pointer-events-none'}`}
          >
            <SpiderWebIcon className="w-full h-full" />
          </div>
        )}
        <a
          href={isWebActive ? undefined : `mailto:${MY_EMAIL}`}
          className="inline-block bg-marvel-red-500 text-white font-bold text-lg px-8 py-4 rounded-md transition-all duration-300 hover:bg-marvel-red-600 hover:scale-105 hover:shadow-marvel-glow"
          style={{ pointerEvents: isWebActive ? 'none' : 'auto' }}
          aria-disabled={isWebActive}
        >
          SAY HELLO
        </a>
      </div>
    </section>
  );
};