import React from 'react';
import { Theme } from '../types';
import { SunIcon, MoonIcon } from '../constants';

interface ThemeToggleProps {
  theme: Theme;
  toggleTheme: () => void;
}

export default function ThemeToggle({ theme, toggleTheme }: ThemeToggleProps) {
  return (
    <button
      onClick={toggleTheme}
      className="w-12 h-6 rounded-full p-1 bg-marvel-gray-700 dark:bg-marvel-gray-800 relative transition-colors duration-500 ease-in-out focus:outline-none focus:ring-2 focus:ring-marvel-red-500"
      aria-label="Toggle theme"
    >
      <div
        className="absolute top-0.5 left-0.5 w-5 h-5 bg-white rounded-full shadow-md transform transition-transform duration-300 ease-in-out"
        style={{ transform: theme === Theme.LIGHT ? 'translateX(0)' : 'translateX(24px)' }}
      >
        {theme === Theme.LIGHT ? 
          <SunIcon className="w-full h-full p-0.5 text-yellow-500" /> :
          <MoonIcon className="w-full h-full p-0.5 text-marvel-dark" />
        }
      </div>
    </button>
  );
};
