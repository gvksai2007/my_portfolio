import React from 'react';

export default function QuoteBanner() {
  const quote = "With Great Power Comes Great Responsibility";
  
  return (
    <div className="w-full bg-marvel-red-600/10 dark:bg-marvel-red-500/10 border-y-2 border-marvel-red-500/50 py-4 overflow-x-hidden">
      <div className="w-[200%] flex animate-marquee">
        <div className="w-1/2 flex justify-center">
            <span className="text-2xl md:text-3xl font-display tracking-wider text-marvel-red-500 mx-12 text-center">{quote}</span>
        </div>
        <div className="w-1/2 flex justify-center">
            <span className="text-2xl md:text-3xl font-display tracking-wider text-marvel-red-500 mx-12 text-center">{quote}</span>
        </div>
      </div>
    </div>
  );
}