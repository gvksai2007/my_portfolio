import React from 'react';
import { InstagramIcon, GithubIcon, LinkedinIcon, SOCIAL_LINKS } from '../constants';

export default function SocialIcons() {
  const handleLinkedInClick = (e: React.MouseEvent<HTMLAnchorElement>) => {
    e.preventDefault();
    alert("Coming Soon!");
  };

  return (
    <div className="flex items-center space-x-5">
      <a href={SOCIAL_LINKS.instagram} target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-marvel-red-500 transition-transform duration-300 hover:scale-110">
        <InstagramIcon />
      </a>
      <a href={SOCIAL_LINKS.github} target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-marvel-red-500 transition-transform duration-300 hover:scale-110">
        <GithubIcon />
      </a>
      <a href={SOCIAL_LINKS.linkedin} onClick={handleLinkedInClick} className="text-gray-400 hover:text-marvel-red-500 transition-transform duration-300 hover:scale-110 cursor-pointer">
        <LinkedinIcon />
      </a>
    </div>
  );
};
